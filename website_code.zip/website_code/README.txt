# Cloudflare Starter Site (Pages + Functions)

This is a minimal, production-ready starter for your site:
- Static HTML/CSS/JS frontend (no build tools required).
- **Slide-out top-left menu** (mobile-friendly).
- Pages Functions endpoints:
  - `POST /api/subscribe` — newsletter signups (validates email; ready to bind KV later).
  - `POST /api/contact` — contact form handler (ready to bind KV or email later).

## Deploy to Cloudflare Pages (Dashboard — no CLI required)
1. Zip and upload this folder as a new **Pages** project (or connect a Git repo).
2. **Build settings:** Set "Framework preset" = *None*. Leave build command empty. Set output directory to `/` (root).
3. Under **Functions**, enable *Pages Functions* (if not auto-detected). Your functions live in `/functions/`.
4. (Optional) Under **Settings → Functions → Bindings**, add KV namespaces:
   - `NEWSLETTER` for /api/subscribe
   - `CONTACTS` for /api/contact
5. Add your custom domain in **Pages → Custom domains** and point DNS (already on Cloudflare via Porkbun).

## Local preview (optional) with Wrangler
```bash
npm create cloudflare@latest          # if you don't have wrangler
wrangler pages dev .                  # serve locally with functions
```
