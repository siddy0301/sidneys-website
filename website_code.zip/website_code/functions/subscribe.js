export async function onRequestPost({ request, env }) {
  const contentType = request.headers.get("content-type") || "";
  let email = "";
  if (contentType.includes("application/json")) {
    const body = await request.json();
    email = body.email || "";
  } else {
    const body = await request.formData();
    email = body.get("email") || "";
  }

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return new Response(JSON.stringify({ ok: false, message: "Please enter a valid email." }), {
      status: 400,
      headers: { "content-type": "application/json" },
    });
  }

  // Example persistence with KV (optional). If you bind a KV named NEWSLETTER in Pages project settings:
  // await env.NEWSLETTER.put(`sub:${email}`, JSON.stringify({ email, ts: Date.now() }));

  return new Response(JSON.stringify({ ok: true, message: "You're on the list! 🎉" }), {
    headers: { "content-type": "application/json" },
  });
}
