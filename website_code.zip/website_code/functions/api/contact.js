export const onRequestGet = () => new Response("contact endpoint OK");

export const onRequestPost = async ({ request, env }) => {
  const ct = request.headers.get("content-type") || "";
  const data = ct.includes("application/json")
    ? await request.json()
    : Object.fromEntries(await request.formData());

  const { name = "", email = "", message = "", website = "" } = data; // website = honeypot

  if (!name || !email || !message) {
    return json({ ok: false, error: "missing_fields" }, 400);
  }
  if (website) return json({ ok: true }); // bot trap

  const body = {
    from: "info@sidneys.net",       // must be on your verified Resend domain
    to: ["info@sidneys.net"],          // your Purelymail inbox
    reply_to: email,
    subject: `New contact from ${name}`,
    text: `Name: ${name}\nEmail: ${email}\n\n${message}`,
    html: `<p><strong>Name:</strong> ${esc(name)}<br><strong>Email:</strong> ${esc(email)}</p>
           <p>${esc(message).replace(/\n/g,"<br>")}</p>`
  };

  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.RESEND_API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!r.ok) {
    const err = await r.text();
    return json({ ok: false, error: `resend_error: ${err}` }, 502);
  }

  return json({ ok: true });
};

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" }});

const esc = s => String(s).replace(/[&<>"']/g, c => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"
}[c]));

