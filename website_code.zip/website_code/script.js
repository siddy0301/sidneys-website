'use strict';
/**
 * Drawer toggle: desktop + iOS Safari safe
 * - Toggles with the same button (open/close)
 * - Works on touch (pointerup/touchend) without ghost double events
 * - Updates ARIA attributes
 * - Closes on overlay click, X button, Esc, or nav link click
 *
 * IDs expected in the HTML:
 *   #menuBtn, #drawer, #overlay, #closeDrawer
 */
(function () {
  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  }

  onReady(function initDrawer() {
    var menuBtn  = document.getElementById('menuBtn');
    var drawer   = document.getElementById('drawer');
    var overlay  = document.getElementById('overlay');
    var closeBtn = document.getElementById('closeDrawer');

    if (!menuBtn || !drawer) return;

    // Avoid double-initializing if this script is included twice
    if (menuBtn.dataset.drawerInit === '1') return;
    menuBtn.dataset.drawerInit = '1';

    function isOpen() {
      return drawer.classList.contains('open');
    }

    function setState(open) {
      if (!drawer) return;
      drawer.classList.toggle('open', !!open);
      if (overlay) overlay.classList.toggle('show', !!open);

      // ARIA state
      drawer.setAttribute('aria-hidden', String(!open));
      if (overlay) overlay.setAttribute('aria-hidden', String(!open));
      menuBtn.setAttribute('aria-expanded', String(!!open));
    }

    function openDrawer()  { setState(true); }
    function closeDrawer() { setState(false); }

    var lastToggleAt = 0;
    var lastTouchAt  = 0;

    function nowMs() {
      return (window.performance && performance.now) ? performance.now() : Date.now();
    }

    function safeToggle(e) {
      if (e) {
        // stop default + bubbling so we don't trigger other listeners
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
      }
      var t = nowMs();
      // Throttle to avoid iOS "touchend + synthetic click" double toggles
      if (t - lastToggleAt < 280) return;
      lastToggleAt = t;

      setState(!isOpen());
    }

    // --- Desktop click (kept) ---
    menuBtn.addEventListener('click', function (e) {
      // If we just handled a touch event, ignore the synthetic click
      if (Date.now() - lastTouchAt < 400) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      safeToggle(e);
    });

    // --- Touch / Pointer handlers for iOS Safari ---
    if (window.PointerEvent) {
      menuBtn.addEventListener('pointerup', function (e) {
        if (e.pointerType === 'touch') {
          lastTouchAt = Date.now();
          safeToggle(e);
        }
      }, { passive: false });
    }
    // Fallback for older iOS (no PointerEvent)
    menuBtn.addEventListener('touchend', function (e) {
      lastTouchAt = Date.now();
      safeToggle(e);
    }, { passive: false });

    // --- Close actions ---
    if (closeBtn) {
      closeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        closeDrawer();
      });
    }

    if (overlay) {
      overlay.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        closeDrawer();
      });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeDrawer();
    });

    // Close when a nav link is clicked/tapped
    try {
      var links = drawer.querySelectorAll('a');
      links.forEach(function (a) {
        a.addEventListener('click', closeDrawer);
      });
    } catch (err) {
      // noop
    }
  });
})();
